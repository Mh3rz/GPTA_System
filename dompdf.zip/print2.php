<?php

require_once "autoload.inc.php";

use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();
$options->set('chroot', realpath(''));
$dompdf = new Dompdf($options);
// instantiate and use the dompdf class
// $dompdf = new Dompdf();

// set the option


// $html = file_get_contents("testprint.php"); 

$dompdf->loadHtml("<img src='h.png'>");

// Set the paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

// Output the PDF to the browser
$dompdf->stream("report.pdf", array("Attachment" => 0));


?>